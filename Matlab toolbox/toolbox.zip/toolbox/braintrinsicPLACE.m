function PLACElabel=braintrinsicPLACE(tree, level)
%%this script generates the .csv file for BRAINtrinsic to visualize tree structure 
%%root level is designated "level 0"
%%written by Alex Leow April 26th 2015

%rootlevel=tree(1);

twolevel=2^(level);
%reOrd=[];

for i=1:twolevel
    branch=tree(level+1, i);
    %reOrd=[reOrd branch{1}];
    PLACElabel(branch{1})=i;
end
PLACElabel=PLACElabel';
csvwrite('braintrinsicPLACE.csv', PLACElabel);


